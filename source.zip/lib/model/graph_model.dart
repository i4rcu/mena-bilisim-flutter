class GraphModel {
  final double x;
  final double y;

  const GraphModel({required this.x, required this.y});
}
