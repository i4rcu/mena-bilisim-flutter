
# fitness_dashboard_ui

This is a complete Fitness Dashboard UI built in Flutter. This repository is for education purposes so that you can learn the concepts of how you can create Responsive Dashboards in Flutter.

![Flutter Dashboard](https://github.com/HeyFlutter-Public/Flutter-Fitness-Dashboard-UI/assets/56497715/a34f073e-79c4-4dea-991d-bba6060bc9a8)


## Getting Started

This is a complete Fitness Dashboard UI built in Flutter. This repository is for education purposes so that you can learn the concepts of how you can create Responsive Dashboards in Flutter.

Check out our YouTube tutorial to learn more in detail about building Responsive Dashboard apps.

Here's the link: https://youtu.be/fVZqxpNdD6c
